---
name: thesis-tracker-zh
description: 投资逻辑跟踪——为每只重点股票维护一份“活文件” /mnt/library/theses/（股票代码）.md：核心逻辑、3–5 根支柱、要盯的指标、失效条件、催化剂和变更记录；每次有新财报、公告或研报时更新，并定期出“投资逻辑周检”。用于“更新一下茅台的投资逻辑”“我的自选股逻辑还成立吗”，以及每周的逻辑跟踪任务。
---

# 投资逻辑跟踪（中文）

先读 `research-standard-zh`。投资逻辑是**活文件**，不是一次性研报：路径固定为 `/mnt/library/theses/<规范代码>.md`（例如 `sh600519.md`），每次更新都在“变更记录”追加一行，不删除历史。

## 投资逻辑文件格式

```markdown
---
title: "贵州茅台（600519）投资逻辑"
type: thesis
lang: zh
tickers: [sh600519]
stance: constructive | neutral | cautious
confidence: high | medium | low
updated: YYYY-MM-DD
status: intact | watch | broken          # 成立 / 需观察 / 已失效
summary: "一句话逻辑"
---

# 贵州茅台（600519）投资逻辑

## 一句话逻辑
## 支柱
| # | 支柱 | 证据 | 要盯的指标（阈值） | 状态 |
| 1 | 提价与直营提升利润率 | … | 毛利率 ≥ 91% | 成立 / 削弱 / 失效 |
## 失效条件（出现任一就重新评估）
## 催化剂（带日期）
## 变更记录
| 日期 | 变化 | 依据（研报 / 公告链接） |
```

## 更新流程
1. 读取现有文件（没有就从最新的个股深度研报里提炼创建）。
2. 收集自上次 `updated` 以来的新信息：研报库里提到该股票的新研报、新公告、财报、价格变化（`market-data`）。
3. 逐条支柱判断状态，写清依据；必要时调整 `stance` / `confidence` / `status`。
4. 追加变更记录，更新 `updated`。
5. 若 `status` 变成 `watch` 或 `broken`，在回复里第一句话说明。

## 周检（定时任务）
读 `/mnt/library/watchlist.yaml` 中的 A股 / 港股，对每只更新投资逻辑文件，然后写一份汇总研报：
`/mnt/library/reports/YYYY/MM/YYYY-MM-DD-thesis-check-zh.md`，type `thesis`，内容为一张表：股票、状态、本周变化、下一个催化剂。状态变化的放最前面。
