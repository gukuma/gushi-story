---
name: market-data
description: Live market numbers for China A-shares, Hong Kong, US indices, FX (USD/CNH, DXY), bond yields, commodities and crypto, plus a call ledger for tracking forecasts. Use whenever a task needs prices, index levels, returns, valuation ratios (PE/PB/market cap), price history, whether the A-share market is open today, or China macro series (CPI, PPI, PMI, M2, LPR). Use before writing any market brief, stock research or macro note, and never quote a price from memory or from a search snippet when this tool can fetch it.
---

# Market Data

Two scripts, standard-library Python, no API keys. Data comes from Tencent Finance,
Sina Finance, Eastmoney's data centre and CoinGecko, all reachable from mainland China.

```
D=/mnt/skills/custom/market-data/scripts
```

Each bash call is a fresh shell: set `D=...;` in the same command, or write the full path.
If `python3` is missing, use `uv run --no-project python` in its place.

## Commands

| Need | Command |
|---|---|
| Cross-asset snapshot (indices, FX, rates, commodities, crypto) | `python3 $D/market_data.py snapshot` |
| One block only | `python3 $D/market_data.py snapshot --set china,fx` (sets: china, global, fx, rates, commodities, crypto) |
| Quotes + PE/PB/market cap | `python3 $D/market_data.py quote 600519 300750 hk00700 AAPL` |
| Daily history + returns, MAs, volatility, drawdown | `python3 $D/market_data.py history 600519 --days 250 --csv /mnt/user-data/outputs/600519.csv` |
| Crypto detail (24h/7d/30d) | `python3 $D/market_data.py crypto bitcoin ethereum` |
| Is the A-share market open today? | `python3 $D/market_data.py trading-day` |
| China macro: CPI, PPI, PMI, M2/M1, retail, IP, trade, GDP, LPR, RRR | `python3 $D/market_data.py macro-cn` |
| Provider health | `python3 $D/market_data.py doctor` |

Add `--json` before or after the subcommand for machine-readable output.

### Symbols

- 6-digit A-share codes are auto-routed: `6xxxxx`/`9xxxxx`/`5xxxxx` → Shanghai, `0/1/2/3xxxxx` → Shenzhen, `4/8xxxxx` → Beijing.
- `000001` means **Ping An Bank** (Shenzhen). For the SSE Composite index write `sh000001`.
- Other indices: `sh000300` (CSI 300), `sh000688` (STAR 50), `sz399006` (ChiNext), `sh000905` (CSI 500).
- Hong Kong: `hk00700` or `700.HK`. US: `AAPL` or `usAAPL`.

### Units

- A-share market caps are in **CNY billions** (Tencent reports 亿; the script converts). Turnover in CNY millions.
- `history` volume is in lots (手 = 100 shares) for A-shares.
- History defaults to forward-adjusted (前复权, `qfq`) prices. Use `--adjust none` for raw prints.
- Rates show the change in basis points.

## Rules for using the numbers

1. **State the as-of time.** Every table prints the pull time and each quote's own timestamp. During holidays and weekends quotes are stale; say "as of the 30 Sep close", not "today".
2. **Run `trading-day` first** in any scheduled brief. If A-shares are closed, write the short holiday version (see the `daily-market-brief` skill).
3. **Cite the source** under every table: "Source: Tencent Finance / Sina Finance / CoinGecko, pulled <time> CST".
4. If a provider fails, say which numbers are missing. Do not fill gaps from memory. Search results can supplement, labelled as such.
5. `macro-cn` flags a series STALE when its newest period is older than expected. Never present a
   stale series as the latest print; get the current release from stats.gov.cn / pbc.gov.cn /
   customs.gov.cn instead. Consensus forecasts are not in this feed; cite a source if you use one.
6. Fundamentals beyond PE/PB/market cap (revenue, margins, cash flow) come from filings. Use the `chinese-sources-first` skill and cninfo.com.cn.

## Call ledger

Every falsifiable call in a report goes into the ledger so the weekly review can score it.

```
L="python3 $D/ledger.py --ledger /mnt/library/calls.csv"   # always pass the path explicitly
$L add --asset "CSI 300" --call "CSI 300 closes above 4,400 on 2026-10-30" --prob 0.55 \
       --resolve-by 2026-10-30 --source reports/2026/10/2026-10-08-a-share-close.md
$L due                                    # open calls past their date
$L propose C0007 --outcome 1 --note "closed 4,431 on 2026-10-30 (Tencent)"   # default: the person confirms in the UI
$L resolve C0007 --outcome 1 --note "..." # only when the person explicitly asks you to grade directly
$L score                                  # Brier, hit rate, calibration buckets
```

A good call is binary, dated and checkable with this tool ("USD/CNH above 6.80 on 31 Oct").
"Sentiment should improve" is not a call. Use probabilities between 0.55 and 0.85 unless you have
unusual evidence; 0.5 means you have no view, so don't log it.

Grading: check every due call with live data, then `propose` an outcome with the evidence in
`--note`. The person confirms or rejects each proposal on the 今日 page; do not `resolve` yourself.

The ledger lives at `/mnt/library/calls.csv` (the shared research library). Always write the path
in the command itself as above; the sandbox maps `/mnt/...` paths only when they appear in the
command line. If `/mnt/library` does not exist, the operator has not mounted it; use
`--ledger /mnt/user-data/outputs/calls.csv` and mention that in the report.
