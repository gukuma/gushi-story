#!/usr/bin/env python3
"""Call ledger: record falsifiable market calls, resolve them later, score calibration.

The ledger is a CSV in the shared research library (default /mnt/library/calls.csv,
override with --ledger or MARKET_LIBRARY). The Market Desk dashboard reads the same file.

  ledger.py add --asset "CSI 300" --call "closes above 4,400 on 2026-10-31" \
                --prob 0.6 --resolve-by 2026-10-31 --source reports/2026/10/2026-10-08-close-brief.md
  ledger.py due                      # open calls whose resolve-by date has passed
  ledger.py resolve C0007 --outcome 1 --note "closed 4,431.2 (Tencent)"
  ledger.py score                    # Brier score, hit rate, calibration buckets
  ledger.py list [--open]
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import sys
from pathlib import Path
from zoneinfo import ZoneInfo

FIELDS = ["id", "created", "source", "asset", "call", "prob", "resolve_by", "status", "outcome", "resolved", "note", "lang"]
CN = ZoneInfo("Asia/Shanghai")


def ledger_path(arg: str | None) -> Path:
    if arg:
        return Path(arg)
    base = os.environ.get("MARKET_LIBRARY", "/mnt/library")
    return Path(base) / "calls.csv"


def load(p: Path) -> list[dict]:
    if not p.exists():
        return []
    with p.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def save(p: Path, rows: list[dict]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in FIELDS})
    tmp.replace(p)


def today() -> str:
    return dt.datetime.now(CN).date().isoformat()


def score(rows: list[dict]) -> dict:
    done = [r for r in rows if r.get("status") == "resolved" and r.get("outcome") in ("0", "1")]
    if not done:
        return {"resolved": 0}
    pairs = [(float(r["prob"]), int(r["outcome"])) for r in done]
    brier = sum((p - o) ** 2 for p, o in pairs) / len(pairs)
    hits = sum(1 for p, o in pairs if (p >= 0.5) == (o == 1))
    # Fold every call onto "confidence in the side I picked" so buckets read 50-100%.
    grouped: dict[int, list[tuple[float, int]]] = {}
    for p, o in pairs:
        conf = max(p, 1 - p)
        right = int((p >= 0.5) == (o == 1))
        lo = min(int(conf * 10), 9) * 10
        grouped.setdefault(lo, []).append((conf, right))
    buckets = {
        f"{lo}-{lo + 10}%": {"n": len(v), "stated": round(sum(c for c, _ in v) / len(v), 3), "realized": round(sum(r for _, r in v) / len(v), 3)}
        for lo, v in sorted(grouped.items())
    }
    return {"resolved": len(done), "brier": round(brier, 4), "hit_rate": round(hits / len(done), 3), "baseline_brier_coinflip": 0.25, "buckets": buckets}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ledger")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add")
    a.add_argument("--asset", required=True)
    a.add_argument("--call", required=True, help="a statement that will be unambiguously true/false on resolve-by")
    a.add_argument("--prob", type=float, required=True, help="probability the statement is TRUE (0.05-0.95)")
    a.add_argument("--resolve-by", required=True, help="YYYY-MM-DD")
    a.add_argument("--source", default="", help="library-relative path of the report making the call")
    a.add_argument("--lang", default="en", choices=["en", "zh"], help="language of the report making the call")
    r = sub.add_parser("resolve")
    r.add_argument("id")
    r.add_argument("--outcome", required=True, choices=["0", "1", "void"])
    r.add_argument("--note", default="")
    pr = sub.add_parser("propose", help="suggest an outcome; the person confirms it in the 股市故事 UI")
    pr.add_argument("id")
    pr.add_argument("--outcome", required=True, choices=["0", "1", "void"])
    pr.add_argument("--note", default="", help="the evidence: value, source, date")
    sub.add_parser("due")
    sc = sub.add_parser("score")
    sc.add_argument("--lang", choices=["en", "zh"], help="score only calls made in this language")
    l_ = sub.add_parser("list")
    l_.add_argument("--open", action="store_true")
    args = ap.parse_args(argv)

    p = ledger_path(args.ledger)
    rows = load(p)

    if args.cmd == "add":
        if not 0.01 <= args.prob <= 0.99:
            ap.error("--prob must be between 0.01 and 0.99")
        dt.date.fromisoformat(args.resolve_by)
        nums = [int(r["id"][1:]) for r in rows if r.get("id", "")[1:].isdigit()]
        nid = f"C{(max(nums) if nums else 0) + 1:04d}"
        row = {"id": nid, "created": today(), "source": args.source, "asset": args.asset, "call": args.call,
               "prob": f"{args.prob:.2f}", "resolve_by": args.resolve_by, "status": "open", "lang": args.lang}
        rows.append(row)
        save(p, rows)
        print(json.dumps(row, ensure_ascii=False))
    elif args.cmd == "resolve":
        for row in rows:
            if row["id"] == args.id:
                row["status"] = "void" if args.outcome == "void" else "resolved"
                row["outcome"] = "" if args.outcome == "void" else args.outcome
                row["resolved"] = today()
                row["note"] = args.note
                save(p, rows)
                print(json.dumps(row, ensure_ascii=False))
                break
        else:
            print(f"no call {args.id}", file=sys.stderr)
            return 1
    elif args.cmd == "propose":
        for row in rows:
            if row["id"] == args.id:
                row["status"] = "proposed"
                row["outcome"] = args.outcome
                row["note"] = args.note
                save(p, rows)
                print(json.dumps(row, ensure_ascii=False))
                break
        else:
            print(f"no call {args.id}", file=sys.stderr)
            return 1
    elif args.cmd == "due":
        t = today()
        due = [x for x in rows if x.get("status") == "open" and x.get("resolve_by", "9999") <= t]
        print(json.dumps(due, ensure_ascii=False, indent=1))
    elif args.cmd == "score":
        sel = [x for x in rows if not args.lang or (x.get("lang") or "en") == args.lang]
        print(json.dumps(score(sel), indent=1))
    elif args.cmd == "list":
        sel = [x for x in rows if not args.open or x.get("status") == "open"]
        print(json.dumps(sel, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
