#!/usr/bin/env python3
"""Market data for the DeerFlow market desk. Standard library only.

Providers (all free, no key, reachable from mainland China):
  - Tencent  qt.gtimg.cn / web.ifzq.gtimg.cn : A-share, HK, US quotes + daily K-lines
  - Sina     hq.sinajs.cn                     : FX, DXY, bond yields, futures, commodities
  - CoinGecko api.coingecko.com               : crypto
  - Eastmoney datacenter-web.eastmoney.com   : China macro releases (CPI, PPI, PMI, M2, retail, IP, trade, GDP, LPR, RRR)

Usage:
  market_data.py snapshot [--set all|china|global|fx|rates|commodities|crypto]
  market_data.py quote 600519 300750 hk00700 usAAPL
  market_data.py history 600519 --days 250 [--csv out.csv]
  market_data.py crypto [bitcoin ethereum ...]
  market_data.py trading-day
  market_data.py macro-cn
  market_data.py doctor
Add --json to any command for machine-readable output.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo

CN_TZ = ZoneInfo("Asia/Shanghai")
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
TIMEOUT = 15

# ---------------------------------------------------------------- instruments
# (label, provider, symbol)
SETS: dict[str, list[tuple[str, str, str]]] = {
    "china": [
        ("上证指数 SSE Composite", "tx", "sh000001"),
        ("深证成指 SZSE Component", "tx", "sz399001"),
        ("创业板指 ChiNext", "tx", "sz399006"),
        ("沪深300 CSI 300", "tx", "sh000300"),
        ("科创50 STAR 50", "tx", "sh000688"),
        ("中证500 CSI 500", "tx", "sh000905"),
        ("恒生指数 Hang Seng", "tx", "hkHSI"),
        ("恒生科技 HS Tech", "tx", "hkHSTECH"),
        ("国企指数 HSCEI", "tx", "hkHSCEI"),
    ],
    "global": [
        ("S&P 500", "tx", "usINX"),
        ("Nasdaq Composite", "tx", "usIXIC"),
        ("Dow Jones", "tx", "usDJI"),
        ("Nikkei 225", "sina_idx", "b_NKY"),
        ("FTSE 100", "sina_idx", "znb_UKX"),
    ],
    "fx": [
        ("USD/CNH 离岸", "sina_fx", "fx_susdcnh"),
        ("USD/CNY 在岸", "sina_fx", "fx_susdcny"),
        ("US Dollar Index DXY", "sina_fx", "DINIW"),
        ("EUR/USD", "sina_fx", "fx_seurusd"),
        ("USD/JPY", "sina_fx", "fx_susdjpy"),
        ("USD/HKD", "sina_fx", "fx_susdhkd"),
    ],
    "rates": [
        ("China 10Y 中国10年国债", "sina_bond", "globalbd_gcny10"),
        ("US 10Y Treasury", "sina_bond", "globalbd_us10yt"),
    ],
    "commodities": [
        ("Gold COMEX (USD/oz)", "sina_fut", "hf_GC"),
        ("Silver COMEX", "sina_fut", "hf_SI"),
        ("Copper COMEX", "sina_fut", "hf_HG"),
        ("Brent crude", "sina_fut", "hf_OIL"),
        ("WTI crude", "sina_fut", "hf_CL"),
        ("SHFE gold 沪金连续 (CNY/g)", "sina_cnfut", "nf_AU0"),
        ("INE crude 上海原油连续", "sina_cnfut", "nf_SC0"),
    ],
    "crypto": [
        ("Bitcoin", "cg", "bitcoin"),
        ("Ethereum", "cg", "ethereum"),
        ("Solana", "cg", "solana"),
    ],
}
SET_ORDER = ["china", "global", "fx", "rates", "commodities", "crypto"]


# ---------------------------------------------------------------- http
def _ssl_context():
    """Python from python.org on macOS ships without root certificates ("CERTIFICATE_VERIFY_FAILED").
    Prefer certifi, then the macOS system bundle, then Python's default."""
    import os
    import ssl
    try:
        import certifi  # type: ignore
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    for cafile in ("/etc/ssl/cert.pem", "/opt/homebrew/etc/ca-certificates/cert.pem", "/usr/local/etc/ca-certificates/cert.pem"):
        if os.path.exists(cafile):
            try:
                return ssl.create_default_context(cafile=cafile)
            except Exception:
                pass
    return ssl.create_default_context()


_SSL = None
# public quote feeds that also answer on plain http — used only if https certificate checks fail
_HTTP_OK = ("qt.gtimg.cn", "web.ifzq.gtimg.cn", "hq.sinajs.cn")


def _get(url: str, *, referer: str | None = None, encoding: str = "utf-8") -> str:
    global _SSL
    if _SSL is None:
        _SSL = _ssl_context()
    headers = {"User-Agent": UA}
    if referer:
        headers["Referer"] = referer
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT, context=_SSL) as resp:
            raw = resp.read()
    except urllib.error.URLError as e:
        host = urllib.parse.urlparse(url).hostname or ""
        if "CERTIFICATE" in str(e).upper() and url.startswith("https://") and host in _HTTP_OK:
            return _get("http://" + url[len("https://"):], referer=referer, encoding=encoding)
        raise
    return raw.decode(encoding, errors="replace")


def _f(x) -> float | None:
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def _pct(now, prev) -> float | None:
    if now is None or prev in (None, 0):
        return None
    return (now / prev - 1) * 100


# ---------------------------------------------------------------- symbols
def normalize_symbol(code: str) -> str:
    """600519 -> sh600519, 000001 -> sz000001 (Ping An Bank), 00700 -> hk00700, AAPL -> usAAPL.

    Index 000001 is ambiguous: pass sh000001 explicitly for the SSE Composite.
    """
    c = code.strip()
    low = c.lower()
    if re.fullmatch(r"(sh|sz|bj|hk|us)[a-z0-9.]+", low):
        return low[:2] + (c[2:].upper() if low.startswith("us") else c[2:])
    m = re.fullmatch(r"(\d{6})\.(sh|ss|sz|bj)", low)
    if m:
        ex = {"ss": "sh"}.get(m.group(2), m.group(2))
        return ex + m.group(1)
    m = re.fullmatch(r"(\d{4,5})\.hk", low)
    if m:
        return "hk" + m.group(1).zfill(5)
    if re.fullmatch(r"\d{6}", c):
        if c[0] in "659":
            return "sh" + c
        if c[0] in "48":
            return "bj" + c
        return "sz" + c
    if re.fullmatch(r"\d{1,5}", c):
        return "hk" + c.zfill(5)
    if re.fullmatch(r"[A-Za-z.\-]{1,8}", c):
        return "us" + c.upper()
    raise ValueError(f"Cannot interpret symbol {code!r}")


# ---------------------------------------------------------------- tencent
def _tx_time(t: str) -> str:
    if re.fullmatch(r"\d{14}", t):
        return f"{t[:4]}-{t[4:6]}-{t[6:8]} {t[8:10]}:{t[10:12]}"
    return t.replace("/", "-")

def tx_quotes(symbols: list[str]) -> list[dict]:
    if not symbols:
        return []
    text = _get("https://qt.gtimg.cn/q=" + ",".join(symbols), encoding="gbk")
    out = []
    for line in text.splitlines():
        if "=" not in line or '""' in line:
            continue
        key, val = line.split("=", 1)
        sym = key.strip().removeprefix("v_")
        f = val.strip().strip('";').split("~")
        if len(f) < 40:
            continue
        market = sym[:2]
        price, prev = _f(f[3]), _f(f[4])
        q = {
            "symbol": sym,
            "name": f[1],
            "price": price,
            "prev_close": prev,
            "open": _f(f[5]),
            "high": _f(f[33]),
            "low": _f(f[34]),
            "change": _f(f[31]),
            "change_pct": _f(f[32]),
            "time": _tx_time(f[30]),
            "pe_ttm": _f(f[39]) if len(f) > 39 else None,
        }
        if market in ("sh", "sz", "bj"):
            is_index = len(f) > 61 and f[61].strip() == "ZS"
            q.update(
                {
                    "currency": "CNY",
                    "volume_lots": _f(f[6]),
                    "turnover_cny_mn": (_f(f[37]) or 0) / 100 if _f(f[37]) is not None else None,  # 万元 -> 百万
                    "turnover_rate_pct": _f(f[38]),
                    "float_mcap_cny_bn": (_f(f[44]) or 0) / 10 if _f(f[44]) else None,  # 亿 -> 十亿
                    "total_mcap_cny_bn": (_f(f[45]) or 0) / 10 if _f(f[45]) else None,
                    "pb": None if is_index else _f(f[46]),
                    "limit_up": None if is_index else _f(f[47]),
                    "limit_down": None if is_index else _f(f[48]),
                    "type": "index" if is_index else "stock",
                }
            )
        elif market == "hk":
            q.update({"currency": "HKD", "turnover_hkd_mn": (_f(f[37]) or 0) / 1e6 if _f(f[37]) else None,
                      "total_mcap_hkd_bn": (_f(f[45]) or 0) / 10 if _f(f[45]) else None})
        elif market == "us":
            q.update({"currency": "USD", "total_mcap_usd_bn": (_f(f[45]) or 0) / 10 if _f(f[45]) else None})
        out.append(q)
    return out


def tx_history(symbol: str, days: int = 250, adjust: str = "qfq") -> list[dict]:
    """Daily OHLCV, oldest first. adjust: qfq (forward-adjusted), hfq, or '' (raw)."""
    days = max(5, min(days, 2000))
    end = dt.datetime.now(CN_TZ).date()
    start = end - dt.timedelta(days=int(days * 1.6) + 10)
    param = f"{symbol},day,{start},{end},{days},{adjust}"
    data = json.loads(_get("https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=" + urllib.parse.quote(param, safe=",")))
    node = (data.get("data") or {}).get(symbol) or {}
    rows = node.get(f"{adjust}day") or node.get("day") or []
    out = []
    for r in rows:
        if len(r) < 6:
            continue
        out.append({"date": r[0], "open": _f(r[1]), "close": _f(r[2]), "high": _f(r[3]), "low": _f(r[4]), "volume": _f(r[5])})
    return out[-days:]


def history_stats(rows: list[dict]) -> dict:
    closes = [r["close"] for r in rows if r["close"] is not None]
    if len(closes) < 2:
        return {}
    last = closes[-1]

    def ret(n):
        return _pct(last, closes[-n - 1]) if len(closes) > n else None

    def ma(n):
        return sum(closes[-n:]) / n if len(closes) >= n else None

    rets = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes)) if closes[i - 1]]
    window = rets[-60:]
    vol = None
    if len(window) > 5:
        mu = sum(window) / len(window)
        vol = math.sqrt(sum((x - mu) ** 2 for x in window) / (len(window) - 1)) * math.sqrt(252) * 100
    peak, mdd = closes[0], 0.0
    for c in closes:
        peak = max(peak, c)
        mdd = min(mdd, c / peak - 1)
    yr = closes[-250:]
    return {
        "first_date": rows[0]["date"],
        "last_date": rows[-1]["date"],
        "last_close": last,
        "ret_5d_pct": ret(5),
        "ret_20d_pct": ret(20),
        "ret_60d_pct": ret(60),
        "ret_250d_pct": ret(250),
        "ma20": ma(20),
        "ma60": ma(60),
        "ma250": ma(250),
        "high_250d": max(yr),
        "low_250d": min(yr),
        "pct_from_250d_high": _pct(last, max(yr)),
        "vol_60d_annualized_pct": vol,
        "max_drawdown_window_pct": mdd * 100,
    }


# ---------------------------------------------------------------- sina
def sina_raw(symbols: list[str]) -> dict[str, list[str]]:
    if not symbols:
        return {}
    text = _get("https://hq.sinajs.cn/list=" + ",".join(symbols), referer="https://finance.sina.com.cn", encoding="gbk")
    out = {}
    for line in text.splitlines():
        m = re.match(r'var hq_str_(\S+?)="(.*)";?', line.strip())
        if m and m.group(2):
            out[m.group(1)] = m.group(2).split(",")
    return out


def sina_parse(provider: str, sym: str, f: list[str]) -> dict:
    if provider == "sina_fx":  # time,bid,ask,?,n,open,high,low,last,name,[chg_pct,chg,...] ; DXY has no chg fields
        price = _f(f[8]) or _f(f[1])
        chg = _f(f[11]) if len(f) > 11 else None
        prev = price - chg if (price is not None and chg is not None) else _f(f[3])
        day = next((x for x in reversed(f) if re.fullmatch(r"\d{4}-\d{2}-\d{2}", x)), "")
        return {"price": price, "prev_close": prev, "high": _f(f[6]), "low": _f(f[7]), "time": f"{day} {f[0]}".strip()}
    if provider == "sina_bond":  # name,last,?,?,?,?,?,chg_pct,chg,...
        price = _f(f[1])
        chg = _f(f[8]) if len(f) > 8 else None
        prev = price - chg if (price is not None and chg is not None) else None
        day = next((x for x in f if re.fullmatch(r"\d{4}-\d{2}-\d{2}", x)), "")
        return {"price": price, "prev_close": prev, "change_pct": None, "change_bp": None if chg is None else round(chg * 100, 1), "time": day}
    if provider == "sina_fut":  # last,,bid,ask,high,low,time,prev_settle,open,...,date,name
        price, prev = _f(f[0]), _f(f[7])
        return {"price": price, "prev_close": prev, "high": _f(f[4]), "low": _f(f[5]), "time": f"{f[12]} {f[6]}"}
    if provider == "sina_cnfut":  # name,time,open,high,low,prev_close?,bid,ask,last,settle,prev_settle,...
        price, prev = _f(f[8]), _f(f[10])
        return {"price": price, "prev_close": prev, "high": _f(f[3]), "low": _f(f[4]), "time": f[17] if len(f) > 17 else ""}
    if provider == "sina_idx":  # name,price,chg,chg_pct,...,date,time
        price, chg = _f(f[1]), _f(f[2])
        prev = price - chg if price is not None and chg is not None else None
        return {"price": price, "prev_close": prev, "time": f"{f[6]} {f[7]}" if len(f) > 7 else ""}
    raise ValueError(provider)


# ---------------------------------------------------------------- coingecko
def cg_markets(ids: list[str]) -> list[dict]:
    url = "https://api.coingecko.com/api/v3/coins/markets?" + urllib.parse.urlencode(
        {"vs_currency": "usd", "ids": ",".join(ids), "price_change_percentage": "24h,7d,30d"}
    )
    data = json.loads(_get(url))
    out = []
    for d in data:
        out.append(
            {
                "symbol": d.get("symbol", "").upper(),
                "name": d.get("name"),
                "price": d.get("current_price"),
                "change_pct": d.get("price_change_percentage_24h_in_currency"),
                "change_7d_pct": d.get("price_change_percentage_7d_in_currency"),
                "change_30d_pct": d.get("price_change_percentage_30d_in_currency"),
                "mcap_usd_bn": (d.get("market_cap") or 0) / 1e9,
                "volume_24h_usd_bn": (d.get("total_volume") or 0) / 1e9,
                "time": d.get("last_updated"),
                "currency": "USD",
            }
        )
    return out


# ---------------------------------------------------------------- commands
def snapshot(sets: list[str]) -> list[dict]:
    rows: list[dict] = []
    for s in sets:
        items = SETS[s]
        try:
            if s == "crypto":
                by_id = {}
                for q in cg_markets([sym for _, _, sym in items]):
                    by_id[q["name"].lower()] = q
                for label, _, sym in items:
                    q = by_id.get(sym) or {}
                    rows.append({"set": s, "label": label, **q})
                continue
            tx_syms = [sym for _, p, sym in items if p == "tx"]
            tx = {q["symbol"]: q for q in tx_quotes(tx_syms)} if tx_syms else {}
            sn_syms = [sym for _, p, sym in items if p.startswith("sina")]
            sn = sina_raw(sn_syms) if sn_syms else {}
            for label, p, sym in items:
                if p == "tx":
                    q = tx.get(sym, {})
                else:
                    q = sina_parse(p, sym, sn[sym]) if sym in sn else {}
                    if "change_pct" not in q:
                        q["change_pct"] = _pct(q.get("price"), q.get("prev_close"))
                rows.append({"set": s, "label": label, "symbol": sym, **q})
        except Exception as e:  # keep going; report the gap
            rows.append({"set": s, "label": f"[{s} unavailable]", "error": f"{type(e).__name__}: {e}"})
    return rows


def trading_day() -> dict:
    now = dt.datetime.now(CN_TZ)
    today = now.date()
    info = {"now_cst": now.strftime("%Y-%m-%d %H:%M"), "weekday": now.strftime("%A")}
    if today.weekday() >= 5:
        return {**info, "a_share_open_today": False, "reason": "weekend"}
    try:
        q = tx_quotes(["sh000001"])[0]
        last_date = dt.date.fromisoformat(q["time"][:10])
        info["last_sse_quote"] = q["time"]
        if now.hour * 60 + now.minute < 9 * 60 + 26:
            info["a_share_open_today"] = None
            info["reason"] = "before 09:26 call auction; cannot confirm yet (check exchange holiday calendar)"
        elif last_date == today:
            info["a_share_open_today"] = True
        else:
            info["a_share_open_today"] = False
            info["reason"] = f"weekday but last SSE print is {last_date} -> exchange holiday"
    except Exception as e:
        info["a_share_open_today"] = None
        info["reason"] = f"could not verify: {e}"
    return info


MACRO_CN = [
    # (label, eastmoney datacenter report, date column, {field: label})
    ("CPI", "RPT_ECONOMY_CPI", "REPORT_DATE", {"NATIONAL_SAME": "YoY %", "NATIONAL_SEQUENTIAL": "MoM %"}),
    ("PPI", "RPT_ECONOMY_PPI", "REPORT_DATE", {"BASE_SAME": "YoY %", "BASE_ACCUMULATE": "YTD index"}),
    ("Official PMI", "RPT_ECONOMY_PMI", "REPORT_DATE", {"MAKE_INDEX": "manufacturing", "NMAKE_INDEX": "non-manufacturing"}),
    ("Money supply", "RPT_ECONOMY_CURRENCY_SUPPLY", "REPORT_DATE", {"BASIC_CURRENCY_SAME": "M2 YoY %", "CURRENCY_SAME": "M1 YoY %", "FREE_CASH_SAME": "M0 YoY %"}),
    ("Retail sales", "RPT_ECONOMY_TOTAL_RETAIL", "REPORT_DATE", {"RETAIL_TOTAL_SAME": "YoY %", "RETAIL_TOTAL_ACCUMULATE_SAME": "YTD YoY %"}),
    ("Industrial production", "RPT_ECONOMY_INDUS_GROW", "REPORT_DATE", {"BASE_SAME": "YoY %", "BASE_ACCUMULATE": "YTD YoY %"}),
    ("Trade (USD)", "RPT_ECONOMY_CUSTOMS", "REPORT_DATE", {"EXIT_BASE_SAME": "exports YoY %", "IMPORT_BASE_SAME": "imports YoY %"}),
    ("GDP", "RPT_ECONOMY_GDP", "REPORT_DATE", {"SUM_SAME": "YTD real YoY %"}),
    ("LPR", "RPTA_WEB_RATE", "TRADE_DATE", {"LPR1Y": "1Y %", "LPR5Y": "5Y %"}),
    ("RRR (large banks)", "RPT_ECONOMY_DEPOSIT_RESERVE", "REPORT_DATE", {"INTEREST_RATE_BA": "RRR after %", "CHANGE_RATE_B": "change pts"}),
]
STALE_DAYS = {"GDP": 200, "LPR": 45, "RRR (large banks)": 100000}


def macro_cn() -> list[dict]:
    """Latest China macro prints from Eastmoney's data centre (mirrors NBS / PBOC / customs releases)."""
    out = []
    today = dt.datetime.now(CN_TZ).date()
    for label, report, date_col, fields in MACRO_CN:
        try:
            url = "https://datacenter-web.eastmoney.com/api/data/v1/get?" + urllib.parse.urlencode(
                {"reportName": report, "columns": "ALL", "sortColumns": date_col, "sortTypes": "-1", "pageSize": "3", "pageNumber": "1"})
            data = json.loads(_get(url, referer="https://data.eastmoney.com/"))
            rows = ((data.get("result") or {}).get("data")) or []
            if not rows:
                raise ValueError(data.get("message") or "empty")
            hist = []
            for r in rows:
                hist.append({"period": r.get("TIME") or str(r.get(date_col, ""))[:10],
                             **{lab: r.get(f) for f, lab in fields.items() if f in r}})
            latest = dt.date.fromisoformat(str(rows[0][date_col])[:10])
            age = (today - latest).days
            out.append({"series": label, "latest_period": hist[0]["period"], "stale": age > STALE_DAYS.get(label, 75),
                        "latest": hist[0], "previous": hist[1:]})
        except Exception as e:
            out.append({"series": label, "error": f"{type(e).__name__}: {e}"})
    return out


def doctor() -> list[dict]:
    checks = [
        ("Tencent quotes (A/HK/US)", lambda: tx_quotes(["sh000001"])[0]["price"]),
        ("Tencent daily K-line", lambda: tx_history("sh600519", 10)[-1]["date"]),
        ("Sina FX/futures/bonds", lambda: list(sina_raw(["fx_susdcnh"]).values())[0][8]),
        ("CoinGecko crypto", lambda: cg_markets(["bitcoin"])[0]["price"]),
        ("Eastmoney macro data centre", lambda: json.loads(_get(
            "https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_ECONOMY_CPI&columns=TIME&sortColumns=REPORT_DATE&sortTypes=-1&pageSize=1&pageNumber=1",
            referer="https://data.eastmoney.com/"))["result"]["data"][0]["TIME"]),
    ]
    out = []
    for name, fn in checks:
        try:
            out.append({"provider": name, "ok": True, "sample": fn()})
        except Exception as e:
            out.append({"provider": name, "ok": False, "error": f"{type(e).__name__}: {e}"})
    return out


# ---------------------------------------------------------------- output
def fmt(v, nd=2):
    if v is None or v == "":
        return "–"
    if isinstance(v, float):
        if abs(v) >= 1e5:
            return f"{v:,.0f}"
        if abs(v) < 20:
            return f"{v:,.4f}".rstrip("0").rstrip(".") if v else "0"
        return f"{v:,.{nd}f}"
    return str(v)


def table(rows: list[dict], cols: list[tuple[str, str]]) -> str:
    head = "| " + " | ".join(h for h, _ in cols) + " |"
    sep = "|" + "|".join("---" for _ in cols) + "|"
    body = []
    for r in rows:
        cells = []
        for _, k in cols:
            v = r.get(k)
            if (k.startswith(("change", "ret_")) and k.endswith("_pct")) and isinstance(v, (int, float)):
                cells.append(f"{v:+.2f}%")
            else:
                cells.append(fmt(v))
        body.append("| " + " | ".join(cells) + " |")
    return "\n".join([head, sep, *body])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--json", action="store_true", help="emit JSON")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("snapshot")
    s.add_argument("--set", default="all", help="all or comma list of: " + ",".join(SET_ORDER))
    q = sub.add_parser("quote")
    q.add_argument("codes", nargs="+")
    h = sub.add_parser("history")
    h.add_argument("code")
    h.add_argument("--days", type=int, default=250)
    h.add_argument("--adjust", default="qfq", choices=["qfq", "hfq", "none"])
    h.add_argument("--csv", help="write OHLCV rows to this CSV path")
    c = sub.add_parser("crypto")
    c.add_argument("ids", nargs="*", default=["bitcoin", "ethereum", "solana", "binancecoin", "ripple"])
    sub.add_parser("trading-day")
    sub.add_parser("macro-cn")
    sub.add_parser("doctor")
    for p in sub.choices.values():
        p.add_argument("--json", action="store_true", help="emit JSON")
    a = ap.parse_args(argv)
    stamp = dt.datetime.now(CN_TZ).strftime("%Y-%m-%d %H:%M CST")

    if a.cmd == "snapshot":
        sets = SET_ORDER if a.set == "all" else [x.strip() for x in a.set.split(",")]
        bad = [x for x in sets if x not in SETS]
        if bad:
            ap.error(f"unknown set(s): {bad}")
        rows = snapshot(sets)
        if a.json:
            print(json.dumps({"as_of": stamp, "rows": rows}, ensure_ascii=False, indent=1, default=str))
        else:
            print(f"# Market snapshot — data pulled {stamp}\n")
            for st in sets:
                part = [r for r in rows if r["set"] == st]
                print(f"## {st}\n")
                chg_col = ("Chg (bp)", "change_bp") if st == "rates" else ("Chg", "change_pct")
                print(table(part, [("Instrument", "label"), ("Last", "price"), ("Prev", "prev_close"), chg_col, ("Quote time", "time")]))
                errs = [r for r in part if r.get("error")]
                for e in errs:
                    print(f"\n> ⚠ {e['error']}")
                print()
            print("Sources: Tencent Finance (qt.gtimg.cn), Sina Finance (hq.sinajs.cn), CoinGecko. Quotes may be delayed; check quote time.")
    elif a.cmd == "quote":
        syms = [normalize_symbol(x) for x in a.codes]
        rows = tx_quotes(syms)
        if a.json:
            print(json.dumps({"as_of": stamp, "rows": rows}, ensure_ascii=False, indent=1))
        else:
            print(f"# Quotes — pulled {stamp}\n")
            print(table(rows, [("Symbol", "symbol"), ("Name", "name"), ("Last", "price"), ("Chg", "change_pct"), ("PE ttm", "pe_ttm"),
                               ("PB", "pb"), ("Mcap bn", "total_mcap_cny_bn"), ("Turnover %", "turnover_rate_pct"), ("Time", "time")]))
            missing = set(syms) - {r["symbol"] for r in rows}
            if missing:
                print(f"\n> ⚠ no data for: {', '.join(sorted(missing))}")
            print("\nSource: Tencent Finance. Mcap in CNY bn for A-shares (HKD/USD bn for others).")
    elif a.cmd == "history":
        sym = normalize_symbol(a.code)
        rows = tx_history(sym, a.days, "" if a.adjust == "none" else a.adjust)
        stats = history_stats(rows)
        if a.csv:
            import csv
            with open(a.csv, "w", newline="", encoding="utf-8") as fh:
                w = csv.DictWriter(fh, fieldnames=["date", "open", "high", "low", "close", "volume"])
                w.writeheader()
                w.writerows(rows)
        if a.json:
            print(json.dumps({"symbol": sym, "as_of": stamp, "stats": stats, "rows": rows if not a.csv else f"written to {a.csv}"}, indent=1))
        else:
            print(f"# {sym} daily history ({len(rows)} bars, adjust={a.adjust}) — pulled {stamp}\n")
            for k, v in stats.items():
                print(f"- {k}: {fmt(v)}")
            print("\nLast 10 bars:\n")
            print(table(rows[-10:], [("Date", "date"), ("Open", "open"), ("High", "high"), ("Low", "low"), ("Close", "close"), ("Volume", "volume")]))
            if a.csv:
                print(f"\nFull series written to {a.csv}")
            print("\nSource: Tencent Finance daily K-line.")
    elif a.cmd == "crypto":
        rows = cg_markets(a.ids)
        if a.json:
            print(json.dumps({"as_of": stamp, "rows": rows}, indent=1))
        else:
            print(f"# Crypto — pulled {stamp}\n")
            print(table(rows, [("Coin", "symbol"), ("USD", "price"), ("24h", "change_pct"), ("7d", "change_7d_pct"), ("30d", "change_30d_pct"),
                               ("Mcap $bn", "mcap_usd_bn"), ("Vol 24h $bn", "volume_24h_usd_bn")]))
            print("\nSource: CoinGecko.")
    elif a.cmd == "trading-day":
        print(json.dumps(trading_day(), ensure_ascii=False, indent=1))
    elif a.cmd == "macro-cn":
        series = macro_cn()
        if a.json:
            print(json.dumps({"as_of": stamp, "series": series}, ensure_ascii=False, indent=1, default=str))
        else:
            print(f"# China macro — latest releases, pulled {stamp}\n")
            for x in series:
                if "error" in x:
                    print(f"- **{x['series']}**: unavailable ({x['error']})")
                    continue
                vals = ", ".join(f"{k} {v:g}" if isinstance(v, (int, float)) else f"{k} {v}" for k, v in x["latest"].items() if k != "period")
                prev = "; ".join(", ".join(f"{v:g}" if isinstance(v, (int, float)) else str(v) for k, v in p.items() if k != "period") + f" ({p['period']})" for p in x["previous"])
                flag = "  ⚠ STALE — check stats.gov.cn / pbc.gov.cn for a newer release" if x["stale"] else ""
                print(f"- **{x['series']}** {x['latest_period']}: {vals}  ·  prior: {prev}{flag}")
            print("\nSource: Eastmoney data centre (data.eastmoney.com), compiled from NBS, PBOC and GACC releases.")
    elif a.cmd == "doctor":
        res = doctor()
        if a.json:
            print(json.dumps(res, ensure_ascii=False, indent=1, default=str))
        else:
            for r in res:
                mark = {True: "OK  ", False: "FAIL", None: "SKIP"}[r["ok"]]
                print(f"[{mark}] {r['provider']}: {r.get('sample', r.get('error'))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
