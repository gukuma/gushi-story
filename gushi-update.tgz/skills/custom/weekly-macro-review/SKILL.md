---
name: weekly-macro-review
description: Weekly review of China macro, PBOC policy, CNY and global FX, rates, commodities and crypto, plus scoring of last week's market calls from the ledger. Use for the scheduled weekend review and whenever asked for "this week in markets", a weekly macro wrap, "how did my calls do", or a China macro/FX/crypto outlook for the coming week.
---

# Weekly Macro, FX & Crypto Review

Runs Saturday morning. Three jobs: (1) what changed in the macro picture this week,
(2) honest scoring of past calls, (3) a short list of what to watch next week.

## Steps

1. **Score the ledger first** (`market-data` skill, `ledger.py`):
   - `ledger.py due` → for each open call past its date, check the outcome with `market_data.py`
     (or a dated source) and `ledger.py --ledger /mnt/library/calls.csv propose <id> --outcome 1|0|void --note "<evidence>"` (a proposal the person confirms in the UI; do not resolve directly).
     Use `void` only when the call was ambiguous; say why.
   - `ledger.py score` → Brier score, hit rate, buckets.
2. **Numbers:** `market_data.py snapshot`, plus `history <code> --days 30` for each index and stock
   on the watchlist (its `ret_5d_pct` / `ret_20d_pct` give 1-week / 1-month moves).
   Crypto: `market_data.py crypto` gives 7d and 30d directly. FX, rates and commodities have no
   history command: take last week's level from last Saturday's review in the library, or say n/a.
3. **China macro:** `python3 /mnt/skills/custom/market-data/scripts/market_data.py macro-cn`.
   For anything marked STALE or unavailable, search stats.gov.cn / pbc.gov.cn for this week's releases.
4. **Policy & flows** (`chinese-sources-first`): PBOC (OMO, MLF, RRR, LPR on the 20th), State Council /
   Politburo signals, CSRC actions, fiscal (special bonds), US data that moved the dollar, Fed speakers,
   crypto ETF flows and regulation (HK SFC licensing, US).
5. **Read last week's briefs** in `/mnt/library/reports/` (same month folder) so the review connects
   to what was written before. Note where earlier briefs were wrong.
6. **Write, log 2–4 new calls with 1–4 week horizons, save.**

## Template

```markdown
---
title: "Weekly macro, FX & crypto review — week ending 2026-10-10"
date: 2026-10-11
type: weekly-review
tickers: [sh000300, hkHSTECH, USDCNH, BTC]
confidence: medium
calls: [C00xx]
summary: "One sentence on the week's regime: e.g. 'Dollar softer, CNH firmer, A-shares range-bound pending October Politburo.'"
---

# Week ending <date>

**The week in three lines.**

## Scorecard: past calls
Resolved this week: table (ID, call, prob, outcome, note).
Running record: N resolved, Brier X.XXX (coin-flip = 0.250), hit rate Y%.
One line of self-critique: where were we overconfident?

## Cross-asset week
Table: asset, level, 1w %, 1m % (indices, USD/CNH, DXY, CN10Y, US10Y, gold, Brent, BTC, ETH).

## China macro & policy
Data released this week vs prior and consensus where available; PBOC actions; policy signals.
Each bullet dated and sourced.

## FX & rates
CNH drivers (fixing vs spot gap, rate differential, PBOC signals), CN-US 10Y spread.

## Crypto
Price, flows, regulation. Only what's material.

## Next week
Dated calendar + what would surprise you.

## New calls
| ID | Call | Prob | Resolves |

## Sources
```

## Rules

- Scoring honesty beats narrative. Report misses plainly.
- "Consensus" figures must cite where they came from; skip them if you can't find one.
- Save to `/mnt/library/reports/YYYY/MM/YYYY-MM-DD-weekly-review.md` and copy to `/mnt/user-data/outputs/`.
