---
name: daily-market-brief
description: Write the pre-market or after-close daily brief for China A-shares with macro, FX, rates, commodities and crypto context, saved to the research library. Use for scheduled morning/close briefs and whenever asked for "today's market", "盘前", "收盘复盘", "what happened in markets", or a daily wrap. Handles holidays by producing a short closed-market note.
---

# Daily Market Brief

Two modes, same skeleton:

- **pre-market** (run ~08:40 CST): what happened overnight, what matters today.
- **close** (run ~15:40 CST): what A-shares did today and why.

The reader is one person who reads it on a phone in 3 minutes. Write tight. Numbers carry the
brief; adjectives don't.

## Steps

1. **Is the market open?**
   `python3 /mnt/skills/custom/market-data/scripts/market_data.py trading-day`
   If `a_share_open_today` is false, write the **holiday note** (below) and stop.
2. **Load the watchlist:** read `/mnt/library/watchlist.yaml`. If missing, use the indices only and say so.
3. **Pull numbers** (never from memory):
   - `market_data.py snapshot` (all sets)
   - `market_data.py quote <every A-share/HK code on the watchlist>`
4. **Find the why.** Load `chinese-sources-first`. Run 4–8 searches, Mandarin first:
   - close mode: `今日A股收盘 原因`, `北向资金 今日` (if still published), `板块 涨幅榜 今日`, `证监会 OR 央行 今日 发布`, one search per watchlist name that moved more than ±3%.
   - pre-market mode: `隔夜美股 中概股`, `今日 经济数据 发布 国家统计局`, `央行 公开市场操作 今日`, `离岸人民币 隔夜`, plus overnight crypto news if BTC moved more than ±3%.
   Only keep explanations that a dated source supports. If you can't find a cause, write "no clear catalyst found".
5. **Make 1–3 calls** and log each in the ledger (see `market-data`). Pre-market calls resolve within 5 trading days; close-mode calls within 20.
6. **Save** (see Output) and reply with the summary line plus the file path.

## Report template

```markdown
---
title: "A-share close brief — 2026-10-08"      # or "Pre-market brief — ..."
date: 2026-10-08
type: daily-brief
mode: close                                     # or pre-market
tickers: [sh000001, sh000300, sh600519]
confidence: medium
calls: [C0012]
summary: "One sentence: the single most important thing today."
---

# A-share close brief — Wed 8 Oct 2026

**Bottom line:** 2–3 sentences. What moved, why, and whether it changes anything.

## Scoreboard
(table: SSE, CSI 300, ChiNext, STAR 50, HSI, HS Tech, USD/CNH, CN10Y, gold, BTC — last, % chg)

## What moved and why
3–5 bullets, each = fact + number + cited cause.  e.g.
- STAR 50 −2.5% as chip names sold off after … ([证券时报, 8 Oct](url))

## Watchlist
(table: name, code, last, % chg, one-line note — only notes for names with news or >±3% moves)

## Macro & cross-asset
2–4 bullets: PBOC operations, FX, yields, commodities, crypto. Skip what didn't move.

## Today / tomorrow
Dated calendar items: data releases, policy meetings, earnings, lock-up expiries.

## Calls
| ID | Call | Prob | Resolves |

## Sources
Numbered list: publisher, title (original language), date, URL. Data line: "Prices: Tencent/Sina/CoinGecko, pulled HH:MM CST".
```

## Holiday note

When A-shares are closed (weekend, Golden Week, Spring Festival):

```markdown
---
title: "Markets note — 2026-10-03 (A-shares closed)"
date: 2026-10-03
type: daily-brief
mode: holiday
confidence: n/a
summary: "A-shares closed for <holiday>; reopen <date>. <One line on HK/US/crypto>."
---
```
Body: the reopening date, then the snapshot for markets that did trade (HK, US, FX, crypto) and at most 3 bullets
on what A-shares will face when they reopen. No calls. Keep it under 200 words.

## Output

- Save to `/mnt/library/reports/YYYY/MM/YYYY-MM-DD-<mode>-brief.md` (create folders as needed).
- Also save the same file to `/mnt/user-data/outputs/` so it appears in the chat.
- If `/mnt/library` is not mounted, save only to outputs and say so in the first line of the reply.

## Quality bar

- Every number has a source and time. Every causal claim has a dated link.
- No "investors are cautious" filler. No buy/sell instructions; this is research, not advice.
- Under 600 words for close mode, 450 for pre-market, excluding tables and sources.
