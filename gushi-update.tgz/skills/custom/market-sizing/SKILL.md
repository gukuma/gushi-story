---
name: market-sizing
description: Market sizing and competitive landscape report with a fixed structure - definition, TAM/SAM/SOM built both top-down and bottom-up, competitors, growth drivers, sources and an explicit confidence grade per number. Use when asked how big a market is, to size an opportunity, map competitors, assess a market for a startup or investment, or for "市场规模" / "竞争格局" questions, in China or elsewhere.
---

# Market Sizing Report

The value of a sizing is in its assumptions, not its headline number. Every figure shows its
arithmetic and source so the reader can swap an assumption and redo it.

## Steps

1. **Pin the definition** before searching: product/service, customer, geography, year, currency,
   revenue vs GMV vs units. Write it in one sentence. Ambiguity here is the most common sizing error.
2. **Research** (load `deep-research`; for China also `chinese-sources-first`):
   - Official statistics (NBS, industry ministries, customs, trade associations)
   - Listed companies' filings (segment revenue gives hard anchors)
   - Research firms (iResearch 艾瑞, Frost & Sullivan, IDC, Euromonitor, CIC 灼识) — note these are often
     commissioned for IPO prospectuses; prospectuses (招股说明书) themselves are excellent sources.
   - Pricing pages, store counts, user numbers for bottom-up inputs
3. **Size it twice:**
   - Top-down: total category spend × share that matches the definition
   - Bottom-up: number of buyers × adoption × price × frequency
   If the two differ by more than 2×, explain why and pick one, or give a range.
4. **Competitors:** 5–10 players, with revenue/scale anchor, positioning, pricing, funding/listing status.
5. **Grade confidence per number** and overall.
6. Pull market data for any listed comparables with `market-data` (`quote` for valuation multiples).

## Template

```markdown
---
title: "<Market> — market sizing"
date: YYYY-MM-DD
type: market-sizing
tickers: [<listed comparables>]
confidence: medium
summary: "TAM ~X (range A–B), SAM ~Y, growth Z% CAGR to 20XX; key uncertainty: ..."
---

# <Market>: size, structure, competitors

**Answer first:** TAM, SAM, SOM with ranges, CAGR, and the single assumption that matters most.

## Definition
One sentence + what's in / out.

## Sizing
### Top-down
Table: step, value, source, confidence (H/M/L).
### Bottom-up
Table: driver, value, source/assumption, confidence.
### Reconciliation
Why the two differ; chosen range.

## Growth drivers & headwinds
3–5 each, with evidence.

## Competitive landscape
Table: company, scale anchor (revenue/users/stores), positioning, price point, status (listed/funded), source.
Short paragraph on structure: fragmented vs concentrated, who's gaining.

## Sensitivity
Which 2–3 assumptions swing the answer most, and the TAM if each moves ±30%.

## Confidence
Overall grade and the weakest link.

## Sources
Numbered; note commissioned research where applicable.
```

## Rules

- Never present a third-party market-size figure without its definition, year and who commissioned it.
- Convert currencies explicitly with the rate and date used.
- Save to `/mnt/library/reports/YYYY/MM/YYYY-MM-DD-<slug>-sizing.md` and copy to `/mnt/user-data/outputs/`.
