---
name: weekly-macro-review-zh
description: 中文版每周宏观、汇率与加密资产复盘，并为上周的预测打分（Brier 分数、命中率）。用于中文模式下的周末定时复盘，以及“本周市场回顾”“宏观周报”“我的预测准不准”“下周关注什么”等请求。Chinese-language weekly macro, FX and crypto review with call scoring.
---

# 每周宏观、汇率与加密资产复盘（中文）

> 先读 `research-standard-zh`（研报规范）：YAML 头、要点先行、数字溯源、反方观点、交付前自检、保存命名都按规范执行。本技能只写本类研报特有的步骤。

周六上午运行。三件事：(1) 本周宏观图景有什么变化；(2) 诚实地给过去的预测打分；(3) 下周关注清单。全文简体中文。

## 步骤

1. **先给预测打分**（`market-data` 技能的 `ledger.py`，路径写全）：
   - `ledger.py --ledger /mnt/library/calls.csv due` → 逐条核对已到期的预测，用 `market_data.py` 或有日期的来源查结果，然后
     `ledger.py --ledger /mnt/library/calls.csv propose <编号> --outcome 1|0|void --note "<证据>"`（只提议，由用户在“今日”页确认；不要直接 resolve）。
     只有预测本身表述含糊时才用 `void`，并说明原因。
   - `ledger.py --ledger /mnt/library/calls.csv score --lang zh` → 中文报告的 Brier 分数、命中率、分段校准；
     再跑一次不带 `--lang` 的，给出全部预测的总成绩。
2. **数据：** `market_data.py snapshot`；对自选里的每个指数和个股跑 `history <代码> --days 30`（`ret_5d_pct` / `ret_20d_pct` 即周涨跌 / 月涨跌）。
   加密资产用 `market_data.py crypto`（直接给 7 日、30 日涨跌）。汇率、利率、大宗没有历史命令：取上周六复盘里的水平，或写“无”。
3. **中国宏观：** `python3 /mnt/skills/custom/market-data/scripts/market_data.py macro-cn`。
   标记为 STALE（过期）或缺失的指标，去国家统计局 / 人民银行官网查本周发布。
4. **政策与资金**（`chinese-sources-first`）：央行（公开市场操作、MLF、降准、每月 20 日 LPR）、国务院 / 政治局信号、证监会动作、
   财政（专项债）、影响美元的美国数据、美联储官员讲话、加密 ETF 资金流与监管（香港证监会牌照、美国）。
5. **回读上周简报：** `/mnt/library/reports/` 当月目录下的中文简报（文件名含 `-zh`），把复盘和之前写过的内容接上，指出之前哪里错了。
6. **撰写，记录 2–4 条新预测（1–4 周期限，加 `--lang zh`），保存。**

## 模板

```markdown
---
title: "宏观、汇率与加密资产周报 — 截至 2026-10-10"
date: 2026-10-11
type: weekly-review
lang: zh
tickers: [sh000300, hkHSTECH, USDCNH, BTC]
confidence: medium
calls: [C00xx]
summary: "一句话概括本周格局，例如：美元走软、人民币走强，A股窄幅震荡，等待十月政治局会议。"
---

# 截至 <日期> 的一周

> **要点**
> 1. …（带最重要的数字）
> 2. …
> 3. …


**三句话看本周。**

## 预测成绩单
本周验证的预测：表格（编号、预测、概率、结果、备注）。
累计：已验证 N 条，Brier X.XXX（抛硬币基准 0.250），命中率 Y%。
一句自我检讨：哪里过度自信了？

## 跨资产一周
表格：资产、水平、周涨跌、月涨跌（主要指数、美元/离岸人民币、美元指数、中国10年、美国10年、黄金、布伦特原油、比特币、以太坊）。

## 中国宏观与政策
本周发布的数据与前值（及有出处的市场预期）；央行操作；政策信号。每条带日期和来源。

## 汇率与利率
人民币驱动因素（中间价与即期价差、利差、央行信号），中美10年期利差。

## 加密资产
价格、资金流、监管。只写重要的。

## 下周关注
带日期的日程 + 什么情况会让你意外。

## 新预测
| 编号 | 预测 | 概率 | 验证日 |

## 来源
```

## 要求

- 打分要诚实，胜过讲好故事。错了就直说。
- 引用“市场预期 / 一致预期”必须注明出处，找不到就不写。
- 保存到 `/mnt/library/reports/YYYY/MM/YYYY-MM-DD-weekly-review-zh.md`，并复制到 `/mnt/user-data/outputs/`。
