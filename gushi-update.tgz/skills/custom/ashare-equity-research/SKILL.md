---
name: ashare-equity-research
description: Structured single-company research note for a China A-share or Hong Kong-listed stock - business, financials from filings, valuation vs history and peers, catalysts, risks, a falsifiable thesis with logged calls, and a confidence grade. Use when asked to research, analyse, deep-dive or "look at" a listed Chinese company or ticker (e.g. 600519, 宁德时代, 00700), or for the weekly watchlist deep dive.
---

# A-share / HK Equity Research Note

Goal: a note Eric can read in 10 minutes and come back to in 3 months to check whether the thesis held.
It is research, not a recommendation. No price targets presented as advice; scenario values are fine.

## Steps

1. **Identify the company.** Resolve name ↔ code ↔ exchange. Note dual listings (A+H) and use both.
2. **Market data** (`market-data` skill):
   - `market_data.py quote <code> <peer codes>` for price, PE, PB, market cap
   - `market_data.py history <code> --days 750 --csv /mnt/user-data/outputs/<code>-history.csv` for 3-year context
3. **Filings first** (`chinese-sources-first` skill). In order:
   - Latest 年报 and most recent 季报/半年报 on cninfo.com.cn (or HKEXnews for H shares). Extract revenue, gross margin, net profit attributable (归母净利润), operating cash flow, capex, net cash/debt, segment split.
   - Recent 公告: buybacks, placements, major contracts, executive changes, lock-up expiries (限售股解禁), pledges (股权质押).
   - 投资者关系活动记录表 (investor-relations Q&A records) for management's own words.
4. **Context:** industry policy (ministry / NDRC / CSRC), 2–3 listed peers, and sell-side or press views only as secondary colour.
5. **Analyse** with the template. Compute what you can (growth, margins, PE vs its own 3-year range from history + EPS).
6. **Log 2–3 calls** in the ledger, 1–6 month horizons, tied to observable things (a reported number, a price level, an event happening).
7. **Save** and reply with the summary + path.

## Template

```markdown
---
title: "<Company 中文名> (<code>) — research note"
date: YYYY-MM-DD
type: equity-research
tickers: [<code>, <peer codes>]
stance: constructive | neutral | cautious
confidence: high | medium | low
calls: [C00xx, C00xx]
summary: "One sentence thesis."
---

# <Company> (<code>) — <one-line thesis>

**Thesis (3 sentences):** what the market prices in, what you think differs, what would prove you wrong.

## Snapshot
Price, market cap (CNY bn), PE ttm, PB, 1y return, 52-week range, as-of time and source.

## Business in one paragraph
How it makes money. Segment table with revenue share and growth.

## Financials (from filings)
Table, last 3 fiscal years + latest interim: revenue, growth, gross margin, net profit attributable,
OCF, net cash. Footnote each column with the filing name and date.

## Valuation
Current PE/PB vs its own 3-year range and vs peers (table). Three scenarios (bear/base/bull) with the
one or two assumptions that drive each. Show the arithmetic.

## Catalysts (dated)
Next earnings date, policy meetings, product launches, unlocks.

## Risks
The 3–5 that matter, each with what you'd watch to see it materialising. Include governance items
(pledges, related-party deals, auditor changes) if any.

## What would change my mind
Concrete triggers.

## Calls
| ID | Call | Prob | Resolves |

## Confidence
High/medium/low and why: data quality, how much depends on management guidance, disagreement among sources.

## Sources
Numbered. Filings first (title in Chinese, date, cninfo URL), then official/policy, then media.
```

## Rules

- Numbers from filings beat numbers from media. When they conflict, use the filing and note the conflict.
- Label every estimate as yours. Separate fact, management claim and your inference.
- If a filing could not be retrieved, say which and lower confidence.
- Save to `/mnt/library/reports/YYYY/MM/YYYY-MM-DD-<code>-research.md` and copy to `/mnt/user-data/outputs/`.
