---
name: chinese-sources-first
description: Source hierarchy and Mandarin search playbook for anything about China - companies, A-shares, policy, macro data, industries, consumers. Searches in Chinese first, prefers primary sources (exchange filings, regulators, statistics bureau), and cites the original page. Use whenever research touches mainland China or Hong Kong, a Chinese company, RMB, or Chinese policy, including inside other research skills.
---

# Chinese Sources First

English-language coverage of China is thin, late and often second-hand. Search in Mandarin, go to
the primary source, and cite that page.

## Search pattern

For every China question, run searches in this order:

1. **Mandarin query** with the specific term: `宁德时代 2026年半年报 归母净利润`, not `CATL earnings`.
2. **Site-restricted query** to a primary source when you know where the answer lives:
   `site:cninfo.com.cn 宁德时代 公告`, `site:stats.gov.cn 2026年9月 CPI`, `site:pbc.gov.cn 公开市场业务交易公告`.
3. **English query** only to add foreign perspective (Reuters, Bloomberg, FT, Caixin Global) or when the
   topic is mainly international.

Use precise Chinese terms: 归母净利润 (net profit attributable), 扣非净利润 (recurring net profit),
经营活动现金流 (operating cash flow), 限售股解禁 (lock-up expiry), 股权质押 (share pledge), 回购 (buyback),
定增 (private placement), 降准 (RRR cut), 逆回购 (reverse repo), 中期借贷便利 MLF, 贷款市场报价利率 LPR,
社融 (total social financing), 专项债 (special bonds), 新质生产力, 以旧换新 (trade-in subsidies).

## Source tiers

| Tier | Use for | Sources |
|---|---|---|
| 1 Primary | Facts, numbers | cninfo.com.cn (巨潮, all A-share filings), sse.com.cn, szse.cn, bse.cn, hkexnews.hk, stats.gov.cn (国家统计局), pbc.gov.cn (人民银行), csrc.gov.cn (证监会), mof.gov.cn, ndrc.gov.cn, gov.cn (国务院), customs.gov.cn (海关), safe.gov.cn (外汇局), chinamoney.com.cn (CFETS fixings) |
| 2 Quality press | Context, causes | 财新 caixin.com, 第一财经 yicai.com, 21世纪经济报道, 证券时报 stcn.com, 上海证券报 cnstock.com, 中国证券报 cs.com.cn, 经济观察报, 晚点 LatePost, 36氪 (tech), Reuters, Bloomberg, FT |
| 3 Data portals | Cross-checks | 东方财富 eastmoney.com, 同花顺 10jqka.com.cn, 新浪财经, 雪球 xueqiu.com (opinion only), Wind/iFinD summaries quoted in press |
| 4 Avoid as evidence | Leads only | 自媒体 WeChat accounts without named authors, 股吧 forums, Zhihu answers, content farms, AI-generated summaries |

Rules:
- A number in a report must come from tier 1, or tier 2 quoting tier 1. Say which.
- Tier 3 numbers are acceptable for market data cross-checks; tier 4 is never evidence.
- When tier 1 and 2 disagree, use tier 1 and note the gap.
- Check the date on everything. Chinese portals re-publish old stories with new timestamps; confirm the
  original publication date.

## Citing

Cite the original-language title, publisher, date and URL:

`[1] 宁德时代：2026年半年度报告, 巨潮资讯网, 2026-07-30, http://www.cninfo.com.cn/...`

When summarising Chinese text in English, keep key terms in Chinese in brackets the first time:
"recurring net profit (扣非净利润) rose 12%".

## Fetching

If `web_fetch` fails on cninfo PDFs or JS pages, try: the announcement's HTML summary page, the
exchange's own site (sse.com.cn / szse.cn), or an eastmoney 公告 mirror (tier 3, cite as such).
If you cannot access the filing, say so; don't paraphrase a filing you haven't read.
